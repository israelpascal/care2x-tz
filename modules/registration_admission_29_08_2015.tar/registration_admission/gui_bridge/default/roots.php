<?php
$root_path='../../../../';
# Root path used in templates
$TP_root_path='../..';
# Top directory path of this module
$top_dir='modules/registration_admission/gui_bridge/default';
?>

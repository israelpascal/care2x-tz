<?php
# This is a trap file, do not remove it from this directory. Do not edit it.
header('location:../../../../index.php');
exit;
?>
